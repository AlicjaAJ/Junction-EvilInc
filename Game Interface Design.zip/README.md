
  # Game Interface Design

  This is a code bundle for Game Interface Design. The original project is available at https://www.figma.com/design/Uh3BtiS0Q1HFS351oyM4oO/Game-Interface-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  